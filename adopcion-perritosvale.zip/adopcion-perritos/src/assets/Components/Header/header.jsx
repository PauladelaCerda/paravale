function Header() {
    return <h1>Adopta un perrito</h1>;

}
export default Header;