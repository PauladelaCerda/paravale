
import './App.css'
import Header from './assets/Components/Header/header';
import MyCard from './assets/Components/MyCard';

function App() {

return (
  <>
<Header />
 
<div>

  <MyCard img="https://www.elcomercio.com/wp-content/uploads/2023/01/perrito-700x391.jpg" />
 
</div>
<div >
<MyCard img= "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRwDQDr_-ah6ggFOcOqjNWFBx30EU5yFrIyvQ&s"/>

</div>

</>
);
}

export default App
